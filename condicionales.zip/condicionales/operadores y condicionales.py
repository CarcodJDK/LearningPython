#Comprobar si un número es par o impar
#Pide un número y di si es par o impar. (Pista: usa el operador % módulo)

num1= int(input("Dame num1:"))

if num1 % 2 == 0:
    print(num1, "es par")
else:
    print("es impar")

num2= int(input("dame num2:"))
if num2 % 2 == 0:
    print(num2 ,"es par")
else:
    print("es impar")