#mayor o menor
#Ejercicio 2 – Mayor de dos números
#Pide dos números y dile al usuario cuál es mayor (o si son iguales).
num1 = int(input("dame el primer num"))
num2 = int(input("dame el segundo num"))

if num1 == num2:
     print("Los números son iguales")
else:
    if num1 > num2:
        print(str(num1) + " es mayor que " + str(num2))
    else:
        print(str(num2) + " es mayor que " + str(num1))