#calculadora simple
#pide 2 numeros y una operacion y muestra el resultado

n1 = float(input("n1:")) #float pq quiero meter decimales
n2= float(input("n2:"))

op=input("selecciona la opción:" \
    "+,-,*,/") #no hace falta print ya que INPUT muestra el mensaje
if op == "+":
    resultado = n1 + n2
elif op == "-":
    resultado = n1- n2
elif op == "*":
    resultado = n1 * n2
elif op == "/":
    if n2 !=0:
     resultado = n1 / n2
    else:
        resultado = "Op no válida, no se puede dividir entre 0"
#mostrar resultado
print("Resultado:", resultado)