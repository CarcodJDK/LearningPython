print("Hola mundo")
print("Hola mundo me llamo carlos")
nombre = "Carlos"
edad = 23
print("Hola,",nombre)
print("El año que viene tendrás...", edad + 1, "años")

entero = 10
decimal = 3.14
texto = "hola"
booleano = True

print(type(entero)) #class int
print(type(decimal)) #class float

nombre = input("Como te llamas?")
print("hola", nombre)

edad = int(carlinput("Cuantos años tienes?"))
print("El año que viene tendre",edad + 1)



